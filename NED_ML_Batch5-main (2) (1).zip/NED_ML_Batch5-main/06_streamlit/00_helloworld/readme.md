# Streamlit Hello World

Install streamlit package

    pip install streamlit    

 Create hello.py and run it:   
    
    streamlit run hello.py

Open http://localhost:8501/