# Learn the Basic Functions

[A Beginners Guide To Streamlit](https://www.geeksforgeeks.org/a-beginners-guide-to-streamlit/)

    streamlit run basics.py