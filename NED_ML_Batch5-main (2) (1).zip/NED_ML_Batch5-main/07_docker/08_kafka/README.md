# Apache Kafka

[Apache Kafka Fundamentals Course](https://www.youtube.com/playlist?list=PLa7VYi0yPIH2PelhRHoFR5iQgflg-y6JA)

https://developer.confluent.io/courses/kafka-python/intro/


https://www.projectpro.io/article/learn-kafka/970

https://www.datacamp.com/tutorial/apache-kafka-for-beginners-a-comprehensive-guide

https://github.com/pmoskovi/kafka-learning-resources

