https://toptechtips.github.io/2023-05-17-docker-compose-multiple-dev-containers/


https://code.visualstudio.com/remote/advancedcontainers/connect-multiple-containers

